# Tensile test data

30 raw tensile tests of round bars (3 materials).

- `data/raw/test_XX.csv`: columns `time_s`, displacement (`displacement_mm` or `displacement_m`, check the header!), `force_N`.
- `data/specimens.csv`: material, cross-section area (mm^2) and gauge length (mm) for each test.

The raw data is not clean. Expect to find problems.
